import java.io.IOException;
import java.util.*;
import java.util.Scanner;

public class Main {
    
    public static void main(String args[]) throws IOException {
    	Scanner s=new Scanner(System.in);
    	int n=s.nextInt();
    	ArrayList<Integer> a=new ArrayList<Integer>(n);
    	for(int i=0;i<n;i++)
    	{
    		a.add(s.nextInt());
    		}

    	System.out.println(UserMainCode.addOdd(a));

    	
    }
    
}


