import java.util.Arrays;

public class UserMainCode {
    
    public static Integer addUnique(Integer[] numbers) {
    	Arrays.sort(numbers);
    Integer sum=numbers[0];
    	for(int i=0;i<numbers.length-1;i++){
    		if(numbers[i]!=numbers[i+1])
    			sum=sum+numbers[i+1];
    	}
    	
		return sum;

    }
    
}
